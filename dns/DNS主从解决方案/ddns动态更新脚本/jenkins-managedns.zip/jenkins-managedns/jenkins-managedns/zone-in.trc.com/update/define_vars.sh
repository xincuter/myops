#!/bin/bash
#description: define env variables...
#version: v1.1
#author: by xinzheng20181220
#email: hzzxin@tairanchina.com

##source function library.
. /etc/rc.d/init.d/functions

##source /etc/profile
. /etc/profile

##define variables
SOURCE="/usr/local/weihu/jenkins-managedns/zone-in.trc.com"
IP_FILE="$SOURCE/update/ip_file"
FQDN_FILE="$SOURCE/update/fqdn_file"
FORWARD_SOURCE="$SOURCE/update/forward-resolution"
REVERSE_SOURCE="$SOURCE/update/reverse-resolution"
FORWARD_IP_FILE="$FORWARD_SOURCE/forward_ip_file"
FORWARD_FQDN_FILE="$FORWARD_SOURCE/forward_fqdn_file"
FORWARD_DDNS_FILE="$FORWARD_SOURCE/forward_ddns_file"
REVERSE_IP_FILE="$REVERSE_SOURCE/reverse_ip_file"
REVERSE_FQDN_FILE="$REVERSE_SOURCE/reverse_fqdn_file"
REVERSE_DDNS_FILE="$REVERSE_SOURCE/reverse_ddns_file"
DDNS_KEY="/etc/named/keys/Ksecupdate.+157+22090.key"
SERVER="10.210.204.63"
CMD="/usr/bin/nsupdate"
