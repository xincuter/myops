#!/bin/bash
#description: dynamic delete forward-resolution domain...
#version: v1.1
#author: by zhengxin20181220
#email: hzzxin@tairanchina.com

##source env
. /usr/local/weihu/jenkins-managedns/zone-in.trc.com/delete/define_vars.sh

##define vars
ZONE="in.trc.com"
TYPE="A"

##generate files(forward_ip_file and forward_fqdn_file)
MK_FILE() {
    ##generate forward_ip file
    \cp -a $IP_FILE $FORWARD_IP_FILE
    ##generate forward_fqdn file
    \cp -a $FQDN_FILE $FORWARD_FQDN_FILE
}

##generate ddns file
MK_DDNS_FILE() {
    MK_FILE
    >$FORWARD_DDNS_FILE

    HOST_NUM=$(wc -l $FORWARD_IP_FILE | awk '{print $1}')
    for i in $(seq 1 $HOST_NUM);do
        IP=$(sed -n "${i}p" $FORWARD_IP_FILE)
        FQDN=$(sed -n "${i}p" $FORWARD_FQDN_FILE)
        echo "update delete $FQDN 600 IN $TYPE $IP" >>$FORWARD_DDNS_FILE
    done

    sed -i -e "1 i server ${SERVER}\n\nzone ${ZONE}" -e "$ a send" $FORWARD_DDNS_FILE
}

##delete
DELETE() {
    if [ $HOST_NUM -le 5 ];then
        $CMD -k $DDNS_KEY <$FORWARD_DDNS_FILE
    else
        $CMD -v -k $DDNS_KEY <$FORWARD_DDNS_FILE
    fi

    if [ $? -eq 0 ];then
        action "Dynamic delete forward-resolution" /bin/true
    else
        action "Dynamic delete forward-resolution" /bin/false
    fi
}

##main
MK_DDNS_FILE
DELETE
