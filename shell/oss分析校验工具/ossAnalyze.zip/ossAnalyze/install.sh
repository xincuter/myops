#!/bin/bash

# Define avaliables
NAME="ossAnalyze"
PREFIX="/usr/local/weihu/scripts"

# Create directory
mkdir -p $PREFIX

# Compress and modify privileges
unzip ./oss.zip -d ${PREFIX}/
chmod +x ${PREFIX}/oss/{bin,env,modules,tools}/*

# Generate profile
echo -e 'export OSSTOOL_HOME=/usr/local/weihu/scripts/oss\nexport PATH=$PATH:$OSSTOOL_HOME/bin' >/etc/profile.d/${NAME}.sh

chmod +x /etc/profile.d/${NAME}.sh
source /etc/profile.d/${NAME}.sh
