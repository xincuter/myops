#!/bin/bash
#description: dynamic update reverse-resolution domain...
#version: v1.1
#author: by xinzheng20181220
#email: hzzxin@tairanchina.com

##source env
. /usr/local/weihu/jenkins-managedns/zone-in.trc.com/update/define_vars.sh

##define vars
ZONE="10.in-addr.arpa"
TYPE="PTR"

##generate files(reverse_ip_file and reverse_fqdn_file)
MK_FILE() {
    >$REVERSE_IP_FILE
    >$REVERSE_FQDN_FILE

    ##generate reverse_ip file
    for REVERSE_IP in $(cat $IP_FILE);do
        echo $REVERSE_IP | awk -F'.' '{ORS=".";for(i=NF;i>=2;i--) print $i}' | sed "s/\.$//g" 
        echo
    done >>$REVERSE_IP_FILE

    ##generate reverse_fqdn file
    \cp -a $FQDN_FILE $REVERSE_FQDN_FILE
    sed -i "/[^\.$]/s#.*#&.#g" $REVERSE_FQDN_FILE
}

##generate ddns file
MK_DDNS_FILE() {
    MK_FILE
    >$REVERSE_DDNS_FILE

    HOST_NUM=$(wc -l $REVERSE_IP_FILE | awk '{print $1}')
    for i in $(seq 1 $HOST_NUM);do
        IP=$(sed -n "${i}p" $REVERSE_IP_FILE)
        FQDN=$(sed -n "${i}p" $REVERSE_FQDN_FILE)
        echo "update delete ${IP}.${ZONE} 600 IN $TYPE $FQDN" >>$REVERSE_DDNS_FILE
        echo "update add ${IP}.${ZONE} 600 IN $TYPE $FQDN" >>$REVERSE_DDNS_FILE
    done

    sed -i -e "1 i server ${SERVER}\n\nzone ${ZONE}" -e "$ a send" $REVERSE_DDNS_FILE
}

##update
UPDATE() {
    if [ $HOST_NUM -le 5 ];then
        $CMD -k $DDNS_KEY <$REVERSE_DDNS_FILE
    else
        $CMD -v -k $DDNS_KEY <$REVERSE_DDNS_FILE
    fi

    if [ $? -eq 0 ];then
        action "Dynamic update reverse-resolution" /bin/true
    else
        action "Dynamic update reverse-resolution" /bin/false
    fi
}

##main
MK_DDNS_FILE
UPDATE
